// Esta función se ejecuta cuando la ventana y todos sus recursos están completamente cargados
window.onload = () => {
  // Obtener el valor de la clave "tabla" del localStorage
  const tabla = localStorage.getItem("tabla");

  // Si el valor es "usuarios", llamar a la función mostrarUsuarios, de lo contrario, llamar a mostrarProductos
  if (tabla === "usuarios") {
    mostrarUsuarios();
  } else {
    mostrarProductos();
  }
};

// Obtener referencias a los botones y tablas relevantes del DOM
const btnUsuarios = document.getElementById("btnUsuarios");
const btnProductos = document.getElementById("btnProductos");
const tablaUsuarios = document.getElementById("tablaAdminUsu");
const tablaProductos = document.getElementById("tablaAdminProdu");

// Función asíncrona para mostrar la tabla de usuarios
const mostrarUsuarios = async () => {
  // Mostrar la tabla de usuarios y deshabilitar el botón de productos
  tablaUsuarios.style.display = "inline-table";
  btnProductos.disabled = false;
  document.getElementById("tituloTabla").innerText = "Usuarios registrados";

  // Guardar el valor "usuarios" en el localStorage
  localStorage.setItem("tabla", "usuarios");
  // Ocultar la tabla de productos
  tablaProductos.style.display = "none";

  try {
    // Hacer una solicitud GET a la API para obtener los usuarios
    const url = "http://localhost:9999/api/usuarios";
    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });

    // Convertir la respuesta a JSON
    const data = await response.json();

    if (data.esValido) {
      // Si la respuesta es válida, construir la tabla de usuarios
      let tabla = document.getElementById("tbodyUsu");
      let contenidoTabla = "";

      data.usuarios.forEach((usuario) => {
        // Determinar el tipo de usuario según el tipo de documento
        let tipoUsuario = "";
        if (usuario.tipoDocumento === "Cedula") {
          tipoUsuario = "Cliente";
        } else if (usuario.tipoDocumento === "Nit") {
          tipoUsuario = "Empresa";
        } else {
          tipoUsuario = "Administrador";
        }

        // Construir las filas de la tabla con los datos del usuario
        contenidoTabla += `
            <tr>
                <td>${usuario.nombreCompleto}</td>
                <td>${usuario.email}</td>
                <td>${usuario.numeroTelefono}</td>
                <td>${usuario.nombreUsuario}</td>
                <td>${usuario.numeroDocumento}</td>
                <td>${tipoUsuario}</td>
            </tr>`;
      });

      // Insertar el contenido de la tabla en el HTML
      tabla.innerHTML = contenidoTabla;

      // Deshabilitar el botón de usuarios
      btnUsuarios.disabled = true;
    } else {
      console.log(data.mensaje);
    }
  } catch (error) {
    console.log(error);
  }
};

// Función asíncrona para mostrar la tabla de productos
const mostrarProductos = async () => {
  // Mostrar la tabla de productos y deshabilitar el botón de usuarios
  tablaProductos.style.display = "inline-table";
  btnUsuarios.disabled = false;
  document.getElementById("tituloTabla").innerText = "Productos guardados";

  // Guardar el valor "productos" en el localStorage
  localStorage.setItem("tabla", "productos");
  // Ocultar la tabla de usuarios
  tablaUsuarios.style.display = "none";

  try {
    // Hacer una solicitud GET a la API para obtener los productos
    const url = "http://localhost:9999/api/sitios";
    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });

    // Verificar si la respuesta es exitosa
    if (!response.ok) {
      console.log("Error al obtener los planes confirmados");
      return;
    }

    // Convertir la respuesta a JSON
    const data = await response.json();

    console.log(data);

    if (data.esValido) {
      // Si la respuesta es válida, construir la tabla de productos
      let tabla = document.getElementById("tbodyProdu");
      let contenidoTabla = "";

      data.listaSitios.forEach((sitio) => {
        // Construir las filas de la tabla con los datos del plan
        contenidoTabla += `
                <tr>
                    <td>${sitio.nombre}</td>
                    <td>${formatoMoneda(sitio.precio)}</td>
                    <td>${sitio.direccion}</td>
                    <td>${sitio.email}</td>
                    <td>${sitio.telefono}</td>
                    <td>${sitio.tipoSitio}</td>
                    <td>${sitio.informacionGeneral}</td>
                </tr>
            `;
      });

      // Insertar el contenido de la tabla en el HTML
      tabla.innerHTML = contenidoTabla;

      // Deshabilitar el botón de productos
      btnProductos.disabled = true;
    } else {
      console.log(data.mensaje);
    }
  } catch (error) {
    console.log(error);
  }
};

// Función para dar formato a un precio como moneda colombiana
const formatoMoneda = (precio) => {
  return new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency: "COP",
  }).format(precio);
};

// Función para cerrar la sesión del usuario y redirigirlo a la página de inicio de sesión
const cerrarSesion = () => {
  localStorage.removeItem("usuario");
  localStorage.removeItem("tabla");
  window.location.href = "/pages/auth/iniciarSesion.html";
};
