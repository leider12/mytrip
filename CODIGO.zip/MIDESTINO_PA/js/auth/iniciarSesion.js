// Función asíncrona para iniciar sesión cuando se envía el formulario
const iniciarSesion = async (e) => {
  // Prevenir el comportamiento predeterminado de enviar el formulario
  e.preventDefault();

  // Obtener los datos del formulario y convertirlos en un objeto
  const data = Object.fromEntries(new FormData(e.target));

  // Validar que ningún campo esté vacío
  if (Object.values(data).some((input) => input === "")) {
    alert("Todos los campos son obligatorios");
    return;
  }

  // URL de la API para iniciar sesión
  const url = "http://localhost:9999/api/login";

  // Realizar una solicitud POST a la API con los datos del formulario
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  });

  // Convertir la respuesta a formato JSON
  const result = await response.json();

  // Si la respuesta es exitosa (código de estado 200)
  if (response.status === 200) {
    // Guardar información del usuario en el localStorage según su tipo
    localStorage.setItem("usuario", JSON.stringify(result.usuario));
    // Redirigir a diferentes páginas según el tipo de usuario
    if (result.usuario.tipoDocumento === "Nit") {
      window.location.href = "/pages/empresa/mainEmpresa.html";
    } else if (result.usuario.tipoDocumento === "Cedula") {
      window.location.href = "/pages/cliente/mainCliente.html";
    } else {
      window.location.href = "/pages/admin/mainAdmin.html";
    }
  } else {
    // Si hay un error en la respuesta, mostrar un mensaje de alerta con el mensaje de error
    alert(result.mensaje);
  }
};

// Agregar un event listener al formulario de inicio de sesión para detectar su envío
document
  .querySelector("#formInicioSesion")
  .addEventListener("submit", iniciarSesion);
