// url de la API para registrar usuarios
const url = "http://localhost:9999/api/usuario";

// Función para abrir el modal de presupuesto
const abrirModal = () => {
  const modal = document.getElementById("modalPresupuestoCli");

  modal.style.display = "flex";
};

const guardarUsuarioTipoCliente = async (e) => {
  e.preventDefault();

  // Cambiar titulo del botón de enviar por un mensaje de carga

  const presupuestoInput = document.getElementById("presupuestoForm").value;

  if (presupuestoInput <= 0) {
    alert("Debe agregar el presupuesto");
    return;
  }

  document.getElementById("btnGuardaPresupuesto").innerHTML = "Enviando...";

  const data = JSON.parse(localStorage.getItem("usuario"));

  // Realizar una solicitud POST a la API con los datos del formulario

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ ...data, presupuesto: presupuestoInput }),
  });

  // Convertir la respuesta a formato JSON

  const result = await response.json();

  // Si la respuesta es exitosa (código de estado 200)

  if (response.status === 200) {
    localStorage.removeItem("usuario");

    // Guardar información del usuario que viene de la respuesta de la base de datos
    localStorage.setItem("usuario", JSON.stringify(result.usuario));

    // Redirigir a la página de cliente
    window.location.href = "/pages/cliente/mainCliente.html";

    document.getElementById("btnGuardaPresupuesto").innerHTML = "Guardar";
  } else {
    // Si hay un error en la respuesta, mostrar un mensaje de alerta con el mensaje de error
    alert(result.mensaje);
  }
};

document
  .getElementById("formModalPresupuesto")
  .addEventListener("submit", guardarUsuarioTipoCliente);

// Función asíncrona para registrar un usuario cuando se envía el formulario
const registrarUsuario = async (e) => {
  // Prevenir el comportamiento predeterminado de enviar el formulario
  e.preventDefault();

  // Obtener los datos del formulario y convertirlos en un objeto
  const data = Object.fromEntries(new FormData(e.target));

  // Validar que ningún campo esté vacío
  if (Object.values(data).some((input) => input === "")) {
    alert("Todos los campos son obligatorios");
    return;
  }

  // URL de la API para registrar usuarios

  if (data.tipoDocumento === "Cedula") {
    localStorage.setItem("usuario", JSON.stringify(data));

    abrirModal({ data });
    return;
  }

  // Realizar una solicitud POST a la API con los datos del formulario
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  });

  // Convertir la respuesta a formato JSON
  const result = await response.json();

  // Si la respuesta es exitosa (código de estado 200)
  if (response.status === 200) {
    // Guardar información del usuario en el localStorage según su tipo
    localStorage.setItem("usuario", JSON.stringify(result.usuario));
    // Redirigir a diferentes páginas según el tipo de usuario
    if (result.usuario.tipoDocumento === "Nit") {
      window.location.href = "/pages/empresa/mainEmpresa.html";
    } else {
      window.location.href = "/pages/admin/mainAdmin.html";
    }
  } else {
    // Si hay un error en la respuesta, mostrar un mensaje de alerta con el mensaje de error
    alert(result.mensaje);
  }
};

// Agregar un event listener al formulario de registro para detectar su envío
if (document.getElementById("formRegistro")) {
  document
    .getElementById("formRegistro")
    .addEventListener("submit", registrarUsuario);
}
