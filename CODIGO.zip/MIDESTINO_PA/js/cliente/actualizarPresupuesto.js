// jhsdfjk

// Función para mostrar el formulario de presupuesto y cambiar el texto del botón según la acción

let accionPresupuesto = "";

const mostrarFormulario = (accion) => {
  document.querySelector("#contieneForm").style.display = "block";

  if (accion === "actualizar") {
    document.querySelector("#tituloPresupuesto").textContent =
      "Actualizar presupuesto";
    document.querySelector("#btnGuardarPresupuesto").textContent =
      "Actualizar presupuesto";

    accionPresupuesto = "actualizar";
  } else {
    document.querySelector("#tituloPresupuesto").textContent =
      "Aumentar presupuesto";
    document.querySelector("#btnGuardarPresupuesto").textContent =
      "Aumentar presupuesto";

    accionPresupuesto = "agregar";
  }
};

// Función asíncrona para actualizar el presupuesto del usuario cuando se envía el formulario
const actualizarPresupuesto = async (e) => {
  // Prevenir el comportamiento predeterminado de enviar el formulario
  e.preventDefault();

  // Obtener los datos del formulario y convertirlos en un objeto
  const data = Object.fromEntries(new FormData(e.target));

  // Validar que ningún campo esté vacío
  if (Object.values(data).some((input) => input === "")) {
    alert("Todos los campos son obligatorios");
    return;
  }

  // Validar que el presupuesto sea un número mayor a 0
  if (Number(data.presupuesto) <= 0) {
    alert("El presupuesto debe ser mayor a 0");
    return;
  }

  // Obtener el usuario del localStorage y convertirlo a objeto
  const usuario = JSON.parse(localStorage.getItem("usuario"));

  let presupuesto = 0;

  // Si la acción es "agregar", el presupuesto ingresado será el nuevo presupuesto + el que ya estaba

  if (accionPresupuesto === "agregar") {
    presupuesto = Number(data.presupuesto) + Number(usuario.presupuesto);
  } else {
    // Si la acción es "actualizar", el presupuesto ingresado será el presupuesto a actualizar
    presupuesto = Number(data.presupuesto);
  }

  // Calcular el nuevo presupuesto sumando el presupuesto anterior del usuario con el nuevo presupuesto ingresado
  const dataUsuario = {
    ...usuario,
    presupuesto: presupuesto,
  };

  // URL de la API para actualizar el usuario
  const url = "http://localhost:9999/api/usuario/" + usuario.idUsuario;

  // Realizar una solicitud PUT a la API para actualizar el usuario con el nuevo presupuesto
  const response = await fetch(url, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(dataUsuario),
  });

  // Convertir la respuesta a formato JSON
  const result = await response.json();

  // Si la respuesta es exitosa (código de estado 200)
  if (response.status === 200) {
    // Eliminar el usuario antiguo del localStorage
    localStorage.removeItem("usuario");

    // Actualizar el usuario en el localStorage con el nuevo presupuesto
    localStorage.setItem("usuario", JSON.stringify(dataUsuario));

    // Llamar a una función en el padre (si existe) para actualizar la vista del presupuesto
    window.parent.cambiarPresupuestoVista(dataUsuario.presupuesto);

    // Limpiar el formulario
    e.target.reset();

    // Mostrar una notificación de éxito utilizando SweetAlert
    Swal.fire({
      title: "¡Presupuesto actualizado!",
      text: "El presupuesto se ha actualizado correctamente.",
      icon: "success",
    });
  } else {
    // Si hay un error en la respuesta, mostrar un mensaje de error
    console.log(result.mensaje);
    Swal.fire({
      title: "¡Error!",
      text: result.mensaje,
      icon: "error",
    });
  }
};

// Agregar un event listener al formulario de presupuesto para detectar su envío
document
  .querySelector("#formPresupuesto")
  .addEventListener("submit", actualizarPresupuesto);
