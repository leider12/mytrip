// Función para mostrar la página seleccionada en el iframe del cliente
const mostrarPaginaSeleccionadaCli = (pagina) => {
  // Guardar la última página seleccionada en el localStorage
  localStorage.setItem("ultimaOpcionSeleccionadaCliente", pagina);

  // Obtener el iframe del cliente por su ID
  let srcIframe = document.getElementById("iframeCliente");

  // Si la página seleccionada es la misma que la actual, no hacer nada
  if (pagina === srcIframe.src) {
    return;
  }

  // Cambiar la fuente del iframe para mostrar la nueva página seleccionada
  srcIframe.src = pagina;
};

// Función que se ejecuta cuando la ventana y todos sus recursos están completamente cargados
window.onload = function () {
  // Obtener la última opción seleccionada del localStorage
  const ultimaOpcion = localStorage.getItem("ultimaOpcionSeleccionadaCliente");

  // Si hay una última opción seleccionada, mostrarla en el iframe del cliente
  if (ultimaOpcion) {
    document.getElementById("iframeCliente").src = ultimaOpcion;
  }

  // Mostrar la información del usuario activo
  infoUsuarioActivo();
};

// Función para mostrar la información del usuario activo
const infoUsuarioActivo = () => {
  // Obtener el usuario del localStorage y convertirlo a objeto
  const usuario = JSON.parse(localStorage.getItem("usuario"));

  // Obtener referencias a los elementos del DOM para mostrar el nombre de usuario y su presupuesto
  const nombreUsuario = document.getElementById("nombreUsuarioActivo");
  const presupuestoUsuario = document.getElementById(
    "presupuestoUsuarioActivo"
  );

  // Mostrar el nombre del usuario y su presupuesto en el DOM
  nombreUsuario.innerHTML = usuario.nombreCompleto;
  presupuestoUsuario.innerHTML = formatoMoneda(usuario.presupuesto);
};

// Función para dar formato a un precio como moneda colombiana
const formatoMoneda = (precio) => {
  return new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency: "COP",
  }).format(precio);
};

// Función para cerrar la sesión del usuario
const cerrarSesion = () => {
  // Eliminar la información del usuario y la última opción seleccionada del localStorage
  localStorage.removeItem("usuario");
  localStorage.removeItem("ultimaOpcionSeleccionadaCliente");
  // Redirigir al usuario a la página de inicio de sesión
  window.location.href = "/pages/auth/iniciarSesion.html";
};

// Función para cambiar el presupuesto mostrado en la vista
function cambiarPresupuestoVista(presupuestoNuevo) {
  // Obtener el elemento padre del presupuesto del usuario
  const elementoPadre = document.getElementById("presupuestoUsuarioActivo");
  // Actualizar el presupuesto en la vista con el nuevo valor
  elementoPadre.innerHTML = formatoMoneda(presupuestoNuevo);
}
