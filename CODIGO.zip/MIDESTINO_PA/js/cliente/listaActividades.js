// Función que se ejecuta cuando la ventana y todos sus recursos están completamente cargados
window.onload = () => {
  // Llamar a la función para obtener las actividades disponibles
  obtenerActividades();
};

// Función asincrónica para obtener las actividades disponibles
const obtenerActividades = async () => {
  // URL de la API para obtener las actividades
  const url = "http://localhost:9999/api/sitios";

  // Realizar una solicitud GET a la API para obtener las actividades
  const response = await fetch(url, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
    },
  });

  // Convertir la respuesta a formato JSON
  const result = await response.json();

  // Variable para almacenar el contenido HTML de las tarjetas de actividades
  let contenidoDeTarjetas = "";

  // Iterar sobre la lista de actividades obtenidas
  result.listaSitios.forEach((actividad) => {
    // Determinar si se debe ocultar o mostrar el botón de escoger actividad según la cantidad disponible
    const esconderBtn = actividad.cantidad <= 0 ? "esconderBtn" : "mostrarBtn";

    // Construir la estructura HTML de cada tarjeta de actividad
    contenidoDeTarjetas += `
    <div class="card">
        <div class="card_contiene_titulo">
            <h5 class="card_titulo">${actividad.nombre}</h5>
            <p class="card_text">${actividad.informacionGeneral}</p>
        </div>
        <ul class="lista_grupo_opciones">
            <li class="lista_item">Categoria: ${actividad.tipoSitio}</li>
            <li class="lista_item">Precio: ${formatoMoneda(
              actividad.precio
            )}</li>
            <li class="lista_item">Horarios: ${actividad.horario}</li>
            <li class="lista_item">Cantidad disponible: ${
              actividad.cantidad
            }</li>
            <li class="lista_item">Correo: ${actividad.email}</li>
            <li class="lista_item">Telefono: ${actividad.telefono}</li>
        </ul>
        <div class="card_btns">
            <button id="btnEscogerActividad" class="btn_card ${esconderBtn}" onclick="escogerActividad(${
      actividad.idSitio
    })">Escoger</button>
        </div>
    </div>
`;
  });

  // Obtener el elemento HTML donde se insertarán las tarjetas de actividades
  const elemento = document.getElementById("actividades");

  // Insertar el contenido HTML de las tarjetas de actividades en el elemento HTML correspondiente
  if (elemento) {
    elemento.innerHTML = contenidoDeTarjetas;
  }
};

// Función asincrónica para escoger una actividad
const escogerActividad = async (idSitio) => {
  // URL de la API para escoger una actividad
  const url = "http://localhost:9999/api/sitioseleccionado";

  // Obtener el usuario del localStorage y convertirlo a objeto
  const usuario = JSON.parse(localStorage.getItem("usuario"));

  // Construir los datos a enviar en la solicitud
  const data = {
    sitio: {
      idSitio,
    },
    usuario: {
      idUsuario: usuario.idUsuario,
    },
  };

  // Realizar una solicitud POST a la API para escoger la actividad
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  });

  // Convertir la respuesta a formato JSON
  const result = await response.json();

  // Mostrar una notificación dependiendo de la respuesta recibida
  if (response.status !== 200) {
    Swal.fire({
      title: "Ya has seleccionado esta actividad",
      text: result.mensaje,
      icon: "info",
    });
  } else {
    Swal.fire({
      title: "Elegiste esta actividad",
      text: "Elegiste la actividad con éxito",
      icon: "success",
    });
  }
};

// Función para dar formato a un precio como moneda colombiana
const formatoMoneda = (precio) => {
  return new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency: "COP",
  }).format(precio);
};
