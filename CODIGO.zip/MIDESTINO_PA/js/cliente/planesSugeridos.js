// Esta función se ejecuta cuando la ventana ha cargado completamente.
window.onload = () => {
  generarPlanesSugeridosDependiendoPresupuesto();
};

// Función asincrónica para obtener todos los sitios desde la API.
const obtenerTodosLosSitios = async () => {
  const url = "http://localhost:9999/api/sitios";

  // Realiza una solicitud GET a la URL especificada para obtener la lista de sitios.
  const response = await fetch(url, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
    },
  });

  // Extrae la lista de sitios de la respuesta JSON.
  const { listaSitios } = await response.json();

  // Retorna la lista de sitios.
  return listaSitios;
};

// Variable global para almacenar las sugerencias de planes separadas.
let listaSugerenciasSeparadas = [];

// Función asincrónica para generar planes sugeridos según el presupuesto del usuario.
const generarPlanesSugeridosDependiendoPresupuesto = async () => {
  // Obtiene todos los sitios disponibles.
  const sitios = await obtenerTodosLosSitios();

  // Obtiene los datos del usuario almacenados en el localStorage.
  const usuario = JSON.parse(localStorage.getItem("usuario"));

  // Filtra los sitios según el presupuesto del usuario y la disponibilidad.
  const planesAcordeAPresupuesto = sitios.filter(
    (sitio) => sitio.precio <= usuario.presupuesto && sitio.cantidad > 0
  );

  // Genera las sugerencias de planes de acuerdo al presupuesto.
  listaSugerenciasSeparadas = planesDeAcuardoAPresupuesto(
    planesAcordeAPresupuesto,
    usuario
  );

  // Obtiene el elemento HTML que mostrará la lista de planes.
  let listaSitios = document.getElementById("listaPlanes");

  // Variable para construir el contenido de las tarjetas de los planes.
  let contenidoDeTarjetas = "";

  // Itera sobre cada actividad sugerida y genera el HTML correspondiente para cada una.
  listaSugerenciasSeparadas.forEach((actividad) => {
    contenidoDeTarjetas += `
        <div class="card">
            <div class="card_contiene_titulo">
                <h5 class="card_titulo" style=font-size:1.5rem >${actividad.nombre.join(
                  ", "
                )}</h5>
                <p class="card_text">${actividad.categoria.join(", ")}</p>
            </div>
            <ul class="lista_grupo_opciones">
                <li class="lista_item">Precio: ${formatoMoneda(
                  actividad.precio
                )}</li>
                <li class="lista_item">Horario: ${actividad.horario.join(
                  ", "
                )}</li>
                <li class="lista_item">Correo: ${actividad.email.join(
                  ", "
                )}</li>
                <li class="lista_item">Telefono: ${actividad.telefono.join(
                  ", "
                )}</li>
            </ul>
            <div class="card_btns">
                <button class="btn_card" onclick="abrirCrearNombrePlan(${
                  actividad.idPlanSugerido
                })">Agregar plan a la lista</button>
            </div>
        </div>`;
  });

  // Inserta el contenido generado en el elemento HTML que muestra la lista de planes.
  if (listaSitios) {
    listaSitios.innerHTML = contenidoDeTarjetas;
  }
};

// Función para abrir el modal para crear un nombre para el plan.
const abrirCrearNombrePlan = (idPlanSugerido) => {
  const modal = document.getElementById("modalGuardarPlanSugerido");
  modal.style.display = "block";

  // Almacena el ID de la actividad seleccionada.
  idActividadSeleccionada = idPlanSugerido;
};

// Función para cerrar el modal para crear un nombre para el plan.
const cerrarCrearNombrePlan = () => {
  const modal = document.getElementById("modalGuardarPlanSugerido");
  modal.style.display = "none";
};

// Variable global para almacenar el ID de la actividad seleccionada.
let idActividadSeleccionada = 0;

// Función asincrónica para agregar un plan a la lista de seleccionados.
const agregarPlanALaListaDeSeleccionados = async (e) => {
  // Previene el comportamiento predeterminado del formulario.
  e.preventDefault();

  // Obtiene los datos del usuario almacenados localmente.
  const usuario = JSON.parse(localStorage.getItem("usuario"));

  // Filtra la actividad seleccionada por su ID.
  const obtenerActividadMedianteId = listaSugerenciasSeparadas.filter(
    (actividad) => actividad.idPlanSugerido === idActividadSeleccionada
  );

  // Obtiene el nombre del plan ingresado por el usuario.
  const nombrePlan = document.getElementById("nombrePlanSuge").value;

  // Verifica si se ha ingresado un nombre para el plan.
  if (nombrePlan === "") {
    mostrarAlerta(
      "¡Nombre del plan vacío!",
      "Por favor, ingresa un nombre para el plan.",
      "error"
    );
    return;
  }

  // Construye el objeto de datos a enviar al servidor para guardar el plan.
  const data = {
    nombrePlan,
    actividades: obtenerActividadMedianteId[0].nombre,
    telefonos: obtenerActividadMedianteId[0].telefono,
    categorias: obtenerActividadMedianteId[0].categoria,
    precios: obtenerActividadMedianteId[0].precio,
    emails: obtenerActividadMedianteId[0].email,
    usuario: {
      idUsuario: usuario.idUsuario,
    },
  };

  // URL a la que se enviarán los datos del nuevo plan.
  const url = "http://localhost:9999/api/plan";

  // Realiza una solicitud POST con los datos del plan al servidor.
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  });

  // Extrae la respuesta del servidor en formato JSON.
  const dataRespo = await response.json();

  // Si la respuesta es exitosa, realiza algunas acciones adicionales.
  if (response.ok) {
    // Reduce la cantidad disponible de la actividad seleccionada en el sitio.
    await restarleUnoCantidadSitio(obtenerActividadMedianteId[0].idSitio);

    // Reduce la cantidad de presupuesto del usuario según el precio de la actividad.
    await restarleCantidadUsuario(
      usuario,
      obtenerActividadMedianteId[0].precio[0]
    );

    // Actualiza la lista de planes sugeridos.
    await generarPlanesSugeridosDependiendoPresupuesto();

    // Cierra el modal para crear un nombre para el plan.
    cerrarCrearNombrePlan();

    // Muestra una alerta de éxito.
    mostrarAlerta(
      "¡Plan guardado!",
      "El plan ha sido guardado exitosamente.",
      "success"
    );
  }
};

// Agrega un listener al formulario en el modal para guardar el plan sugerido.
document
  .getElementById("modalGuardarPlanSugerido")
  .addEventListener("submit", agregarPlanALaListaDeSeleccionados);

// Función para dividir los planes acorde al presupuesto del usuario.
const planesDeAcuardoAPresupuesto = (planesAcordeAPresupuesto, usuario) => {
  // Objeto para almacenar los datos de las actividades.
  let dataALlenar = {
    idSitios: [],
    categorias: [],
    nombres: [],
    precios: [],
    horarios: [],
    emails: [],
    telefonos: [],
  };

  // Lista para almacenar las sugerencias de planes separadas.
  let listaSugerenciasSeparadas = [];

  // Itera sobre cada sitio filtrado y llena el objeto de datos.
  planesAcordeAPresupuesto.forEach((sitio, index) => {
    dataALlenar.idSitios.push(sitio.idSitio);
    dataALlenar.categorias.push(sitio.tipoSitio);
    dataALlenar.nombres.push(sitio.nombre);
    dataALlenar.precios.push(sitio.precio);
    dataALlenar.horarios.push(sitio.horario);
    dataALlenar.emails.push(sitio.email);
    dataALlenar.telefonos.push(sitio.telefono);

    // Si el índice es impar o es el último elemento, agrega la sugerencia a la lista.
    if (index % 2 !== 0 || index === planesAcordeAPresupuesto.length - 1) {
      listaSugerenciasSeparadas.push({
        idPlanSugerido: Math.floor(Math.random() * 1000),
        idSitio: dataALlenar.idSitios,
        categoria: dataALlenar.categorias,
        nombre: dataALlenar.nombres,
        precio: [calcularTotalAPagar(dataALlenar.precios)],
        horario: dataALlenar.horarios,
        email: dataALlenar.emails,
        telefono: dataALlenar.telefonos,
      });

      // Reinicia el objeto de datos para la próxima iteración.
      dataALlenar.idSitios = [];
      dataALlenar.categorias = [];
      dataALlenar.nombres = [];
      dataALlenar.precios = [];
      dataALlenar.horarios = [];
      dataALlenar.emails = [];
      dataALlenar.telefonos = [];
    }
  });

  // Filtra las sugerencias por precio para ajustarse al presupuesto del usuario.
  return listaSugerenciasSeparadas.filter(
    (sitio) => sitio.precio <= usuario.presupuesto
  );
};

// Función para restar la cantidad de presupuesto del usuario.
const restarleCantidadUsuario = async (usuario, totalAPagar) => {
  try {
    // URL para actualizar los datos del usuario.
    const url = `http://localhost:9999/api/usuario/${usuario.idUsuario}`;

    // Objeto con los nuevos datos del usuario.
    const dataUsuario = {
      ...usuario,
      presupuesto: Number(usuario.presupuesto) - Number(totalAPagar),
    };

    // Realiza una solicitud PUT para actualizar los datos del usuario en el servidor.
    const response = await fetch(url, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(dataUsuario),
    });

    // Si la solicitud es exitosa, actualiza los datos del usuario almacenados localmente.
    if (response.ok) {
      localStorage.removeItem("usuario");
      localStorage.setItem("usuario", JSON.stringify(dataUsuario));

      // Actualiza la vista con el nuevo presupuesto del usuario.
      window.parent.cambiarPresupuestoVista(dataUsuario.presupuesto);

      console.log("Presupuesto restado al pagar el plan.");
    } else {
      console.log("Error al restar presupuesto al pagar el plan.");
    }
  } catch (error) {
    console.log(error);
  }
};

// Función asincrónica para restar uno a la cantidad disponible de un sitio.
const restarleUnoCantidadSitio = async (listaConId) => {
  try {
    // Mapea sobre la lista de IDs de sitios para actualizar la cantidad disponible en cada uno.
    const actualizarCantidadSitios = listaConId.map(async (idSitio) => {
      // URL para obtener los datos del sitio específico.
      const url = `http://localhost:9999/api/sitio/${idSitio}`;

      // Realiza una solicitud GET para obtener los datos del sitio.
      const response = await fetch(url, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      // Extrae los datos del sitio de la respuesta JSON.
      const { sitio } = await response.json();

      // Calcula la nueva cantidad restando uno.
      const dataSitio = {
        ...sitio,
        cantidad: sitio.cantidad - 1,
      };

      // Realiza una solicitud PUT para actualizar la cantidad del sitio en el servidor.
      const putResponse = await fetch(url, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(dataSitio),
      });

      // Si la solicitud PUT es exitosa, muestra un mensaje de éxito.
      if (putResponse.ok) {
        console.log("Se restó uno a la cantidad del sitio.");
      } else {
        console.log("Error al restar uno a la cantidad del sitio.");
      }
    });

    // Espera a que todas las actualizaciones de cantidad se completen antes de continuar.
    await Promise.all(actualizarCantidadSitios);
  } catch (error) {
    console.log(error);
  }
};

// Función para calcular el total a pagar sumando los precios de una lista de precios.
const calcularTotalAPagar = (precios) => {
  let totalAPagar = 0;

  // Itera sobre la lista de precios y suma cada uno al total.
  precios.map((precio) => {
    totalAPagar += precio;
  });

  return totalAPagar;
};

// Función para dar formato a un precio como moneda colombiana (COP).
const formatoMoneda = (precio) => {
  return new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency: "COP",
  }).format(precio);
};

// Función para mostrar una alerta utilizando la librería Swal (SweetAlert).
const mostrarAlerta = (titulo, mensaje, icono) => {
  Swal.fire({
    title: titulo,
    text: mensaje,
    icon: icono,
  });
};
