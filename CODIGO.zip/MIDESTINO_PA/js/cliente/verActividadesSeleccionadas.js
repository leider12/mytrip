// Función para cargar la lista de actividades seleccionadas cuando la ventana haya cargado completamente.
window.onload = () => {
  verActividadesSeleccionadas();
};

// Arreglo para almacenar las actividades seleccionadas.
let actividadesSeleccionadas = [];

// Función asincrónica para obtener y mostrar las actividades seleccionadas por el usuario.
const verActividadesSeleccionadas = async () => {
  try {
    // Obtiene los datos del usuario almacenados localmente.
    const usuario = JSON.parse(localStorage.getItem("usuario"));

    // URL para obtener las actividades seleccionadas del usuario.
    const url = `http://localhost:9999/api/sitioseleccionados/${usuario.idUsuario}/usuario`;

    // Realiza una solicitud GET para obtener las actividades seleccionadas.
    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });

    // Extrae las actividades seleccionadas de la respuesta JSON.
    const sitios = await response.json();

    // Almacena las actividades seleccionadas en el arreglo.
    actividadesSeleccionadas = sitios;

    // Obtiene los elementos HTML de la tabla donde se mostrarán las actividades.
    const tablaBody = document.getElementById("tablaTbody");
    const tablaFoot = document.getElementById("tablaTfoot");

    // Variables para construir el contenido de la tabla y el pie de tabla.
    let contenidoDeTabla = "";
    let contenidoDeTablaFoot = "";

    let totalAPagar = 0;

    // Itera sobre cada actividad seleccionada y construye las filas de la tabla.
    sitios.forEach(({ sitio, idSitioSeleccionado }) => {
      // Suma el precio de la actividad al total a pagar.
      totalAPagar += sitio.precio;

      // Construye la fila de la tabla para la actividad.
      contenidoDeTabla += `
            <tr>
                <td>${sitio.nombre}</td>
                <td>${sitio.tipoSitio}</td>
                <td>${sitio.email}</td>
                <td>${formatoMoneda(sitio.precio)}</td>
                <td>${sitio.telefono}</td>
                <td class="td_elimina_actividad">
                    <button class="btn_eliminar_actividad" onclick="eliminarActividad(${idSitioSeleccionado})">
                        <i class="fa-regular fa-trash-can"></i>
                    </button>
                </td>
            </tr>   
        `;
    });

    // Construye la fila de pie de tabla que muestra el total a pagar.
    contenidoDeTablaFoot = `
    <tr>
        <td>Total a pagar:</td>
        <td></td>
        <td></td>
        <td>${formatoMoneda(totalAPagar)} pesos</td>
    </tr>
  `;

    // Inserta el contenido construido en los elementos HTML de la tabla.
    if (tablaBody) {
      tablaBody.innerHTML = contenidoDeTabla;
    }

    if (tablaFoot) {
      tablaFoot.innerHTML = contenidoDeTablaFoot;
    }
  } catch (error) {
    console.log(error);
  }
};
// Función para dar formato a un precio como moneda colombiana (COP).
const formatoMoneda = (precio) => {
  return new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency: "COP",
  }).format(precio);
};

// Función para eliminar una actividad seleccionada por su ID.
const eliminarActividad = async (id) => {
  // URL para eliminar la actividad seleccionada.
  const url = `http://localhost:9999/api/sitioseleccionado/${id}`;

  // Realiza una solicitud DELETE para eliminar la actividad.
  const response = await fetch(url, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
    },
  });

  // Si la solicitud es exitosa, muestra un mensaje de éxito y actualiza la lista de actividades seleccionadas.
  if (response.ok) {
    Swal.fire({
      title: "¡Actividad eliminada!",
      text: "La actividad ha sido eliminada correctamente.",
      icon: "success",
    });

    verActividadesSeleccionadas();
  } else {
    // Si hay un error, muestra un mensaje de error.
    Swal.fire({
      title: "¡Error!",
      text: "No se pudo eliminar la actividad.",
      icon: "error",
    });
  }
};

// Función para abrir el modal para guardar un plan.
const abrirModal = () => {
  const modal = document.getElementById("modalGuardarPlan");
  modal.style.display = "block";
};

// Evento click para abrir el modal cuando se haga clic en el botón correspondiente.
document
  .getElementById("btnAbrirModalGuardar")
  .addEventListener("click", () => {
    abrirModal();
  });

// Función para cerrar el modal.
const cerrarModal = () => {
  const modal = document.getElementById("modalGuardarPlan");
  modal.style.display = "none";
};

// Evento click para cerrar el modal cuando se haga clic en el botón cancelar.
document.getElementById("btnCancelarPlan").addEventListener("click", () => {
  cerrarModal();
});

// Función para guardar las actividades seleccionadas como un plan.
const guardarActividadesSeleccionadas = async (e) => {
  e.preventDefault();

  try {
    // Obtiene el nombre del plan ingresado por el usuario.
    const nombrePlan = document.getElementById("nombrePlan").value;
    const usuario = JSON.parse(localStorage.getItem("usuario"));

    // Valida que se haya ingresado un nombre para el plan.
    if (nombrePlan === "") {
      mostrarAlerta(
        "¡Nombre del plan vacío!",
        "Por favor, ingresa un nombre para el plan.",
        "error"
      );
      return;
    }

    // Convierte los datos de las actividades seleccionadas en un formato adecuado para guardar.
    const data = convertirDatosEnTexto(actividadesSeleccionadas, usuario);
    const totalAPagar = calcularTotalAPagar(data.precios);

    // Valida que haya actividades seleccionadas para guardar.
    if (data.actividades.length === 0) {
      mostrarAlerta(
        "¡Plan vacío!",
        "No hay actividades seleccionadas para guardar.",
        "error"
      );
      return;
    }

    // Valida que el usuario tenga suficiente presupuesto para guardar el plan.
    if (usuario.presupuesto < totalAPagar) {
      mostrarAlerta(
        "¡Presupuesto insuficiente!",
        "No tienes suficiente presupuesto para guardar este plan.",
        "error"
      );
      return;
    }

    // URL para guardar el plan en la base de datos.
    const url = "http://localhost:9999/api/plan";

    // Realiza una solicitud POST para guardar el plan en la base de datos.
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    // Obtiene la respuesta JSON de la solicitud.
    const result = await response.json();

    // Si el plan se guarda correctamente, realiza las operaciones necesarias y muestra un mensaje de éxito.
    if (result.esValido) {
      await eliminarActividadesSeleccionadas();
      await restarleCantidadUsuario(usuario, totalAPagar);
      await restarleUnoCantidadSitio();
      actividadesSeleccionadas = [];
      verActividadesSeleccionadas();
      cerrarModal();
      mostrarAlerta(
        "¡Plan guardado!",
        "El plan ha sido guardado correctamente.",
        "success"
      );
    }
  } catch (error) {
    // Si hay un error, muestra un mensaje de error.
    console.log(error);
    mostrarAlerta("¡Error!", "No se pudo guardar el plan.", "error");
  }
};

// Evento submit para guardar el plan cuando se envíe el formulario.
document
  .getElementById("formGuardarPlan")
  .addEventListener("submit", guardarActividadesSeleccionadas);

// Función para mostrar una alerta utilizando la librería Swal.
const mostrarAlerta = (titulo, mensaje, icono) => {
  Swal.fire({
    title: titulo,
    text: mensaje,
    icon: icono,
  });
};

// Función para calcular el total a pagar sumando los precios de un arreglo de precios.
const calcularTotalAPagar = (precios) => {
  let totalAPagar = 0;

  precios.map((precio) => {
    totalAPagar += precio;
  });

  return totalAPagar;
};

// Función para eliminar todas las actividades seleccionadas de la base de datos.
const eliminarActividadesSeleccionadas = async () => {
  try {
    // Mapea sobre todas las actividades seleccionadas y realiza una solicitud DELETE para eliminarlas de la base de datos.
    const deleteRequests = actividadesSeleccionadas.map(async (element) => {
      const deleteUrl = `http://localhost:9999/api/sitioseleccionado/${element.idSitioSeleccionado}`;

      const deleteResponse = await fetch(deleteUrl, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
      });

      // Si la solicitud no es exitosa, muestra un mensaje de error.
      if (!deleteResponse.ok) {
        console.log(`Failed to delete ${element.idSitioSeleccionado}`);
      }
    });

    // Espera a que todas las solicitudes de eliminación se completen.
    await Promise.all(deleteRequests);
  } catch (error) {
    console.log(error);
  }
};

// Función para restarle la cantidad de dinero gastada por el usuario al presupuesto del mismo.
const restarleCantidadUsuario = async (usuario, totalAPagar) => {
  try {
    const url = `http://localhost:9999/api/usuario/${usuario.idUsuario}`;

    // Crea un nuevo objeto de usuario con el presupuesto actualizado.
    const dataUsuario = {
      ...usuario,
      presupuesto: Number(usuario.presupuesto) - Number(totalAPagar),
    };

    // Realiza una solicitud PUT para actualizar el usuario con el nuevo presupuesto.
    const response = await fetch(url, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(dataUsuario),
    });

    // Si la solicitud es exitosa, actualiza el usuario almacenado localmente y realiza otras operaciones necesarias.
    if (response.ok) {
      localStorage.removeItem("usuario");
      localStorage.setItem("usuario", JSON.stringify(dataUsuario));
      window.parent.cambiarPresupuestoVista(dataUsuario.presupuesto);
      console.log("Presupuesto restado al pagar el plan.");
    } else {
      console.log("Error al restar presupuesto al pagar el plan.");
    }
  } catch (error) {
    console.log(error);
  }
};

const restarleUnoCantidadSitio = async () => {
  try {
    const actualizarCantidadSitios = actividadesSeleccionadas.map(
      async (element) => {
        const url = `http://localhost:9999/api/sitio/${element.sitio.idSitio}`;

        const response = await fetch(url, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        });

        const { sitio } = await response.json();

        const dataSitio = {
          ...sitio,
          cantidad: sitio.cantidad - 1,
        };

        const putResponse = await fetch(url, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(dataSitio),
        });

        if (putResponse.ok) {
          console.log("Se restó uno a la cantidad del sitio.");
        } else {
          console.log("Error al restar uno a la cantidad del sitio.");
        }
      }
    );

    await Promise.all(actualizarCantidadSitios);
  } catch (error) {
    console.log(error);
  }
};

const convertirDatosEnTexto = (arraySele, usuario) => {
  const data = {
    nombrePlan: document.getElementById("nombrePlan").value,
    actividades: [],
    telefonos: [],
    categorias: [],
    precios: [],
    emails: [],
    usuario: { idUsuario: usuario.idUsuario },
  };

  arraySele.forEach(({ sitio }) => {
    data.actividades.push(sitio.nombre);
    data.telefonos.push(sitio.telefono);
    data.categorias.push(sitio.tipoSitio);
    data.precios.push(Number(sitio.precio));
    data.emails.push(sitio.email);
  });

  return data;
};
