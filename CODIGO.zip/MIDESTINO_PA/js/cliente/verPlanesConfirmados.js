// Cuando la ventana se carga completamente, se ejecuta la función `obtenerPlanesConfirmados`.
window.onload = () => {
  obtenerPlanesConfirmados();
};

// Definición de la función asíncrona `obtenerPlanesConfirmados`.
const obtenerPlanesConfirmados = async () => {
  try {
    // Obtiene los datos del usuario almacenados en localStorage y los convierte de JSON a objeto.
    const usuario = JSON.parse(localStorage.getItem("usuario"));

    // Construye la URL para obtener los planes confirmados del usuario específico.
    const url = `http://localhost:9999/api/planes/${usuario.idUsuario}`;

    // Realiza una solicitud HTTP GET a la URL especificada.
    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });

    // Verifica si la respuesta de la solicitud no es exitosa.
    if (!response.ok) {
      // Muestra un mensaje de error en la consola si la solicitud falla.
      console.log("Error al obtener los planes confirmados");
      return; // Termina la ejecución de la función si hay un error.
    }

    // Convierte la respuesta de la solicitud en un objeto JSON.
    const { listaPlanesGuardados } = await response.json();

    // Obtiene el elemento del DOM donde se mostrarán los planes confirmados.
    const tbodyPlanesConfirmados = document.getElementById(
      "tbodyPlanesConfirmados"
    );

    // Inicializa una cadena vacía para construir el contenido HTML de la tabla.
    let contenidoDeTabla = "";

    // Inicializa una variable para llevar el total gastado en todos los planes.
    let totalGastado = 0;

    // Itera sobre cada plan en la lista de planes guardados.
    listaPlanesGuardados.forEach((plan) => {
      // Inicializa una variable para calcular el costo total de cada plan.
      let totalPlan = 0;

      // Suma todos los precios del plan actual para obtener el total del plan.
      plan.precios.forEach((precio) => {
        totalPlan += precio;
      });

      // Añade el total del plan al total gastado.
      totalGastado += totalPlan;

      // Construye una fila de tabla en formato HTML con los datos del plan.
      contenidoDeTabla += `
                <tr>
                    <td>${plan.nombrePlan}</td>
                    <td>${formatoMoneda(totalGastado)}</td>
                    <td>${plan.actividades.join(", ")}</td>
                    <td>${plan.emails.join(", ")}</td>
                    <td>${plan.telefonos.join(", ")}</td>
                    <td>${plan.categorias.join(", ")}</td>
                </tr>
            `;

      // Reinicia el total gastado para el próximo plan (parece ser un error, debería mantenerse acumulado).
      totalGastado = 0;
    });

    // Si existe el elemento del DOM `tbodyPlanesConfirmados`, inserta el contenido HTML construido.
    if (tbodyPlanesConfirmados) {
      tbodyPlanesConfirmados.innerHTML = contenidoDeTabla;
    }
  } catch (error) {
    // Captura cualquier error que ocurra durante la ejecución de la función y lo muestra en la consola.
    console.log(error);
  }
};

// Función para formatear un precio en moneda colombiana (COP).
const formatoMoneda = (precio) => {
  return new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency: "COP",
  }).format(precio);
};
