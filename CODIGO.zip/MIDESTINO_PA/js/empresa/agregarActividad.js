const agregarSitio = async (e) => {
  e.preventDefault();

  const data = Object.fromEntries(new FormData(e.target));

  // Validar que los campos no estén vacíos
  if (Object.values(data).some((input) => input === "")) {
    alert("Todos los campos son obligatorios");
    return;
  }

  const usuario = JSON.parse(localStorage.getItem("usuario"));

  const nuevaData = {
    ...data,
    usuario: { idUsuario: usuario.idUsuario },
  };

  // hacer peticion a la API

  const url = "http://localhost:9999/api/sitio";

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(nuevaData),
  });

  const result = await response.json();

  if (response.status === 200) {
    document.getElementById("formSitioEmpresa").reset();
  } else {
    alert(result.mensaje);
  }
};

document
  .querySelector("#formSitioEmpresa")
  .addEventListener("submit", agregarSitio);
