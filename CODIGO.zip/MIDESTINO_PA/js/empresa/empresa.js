// Redirecciones de la página de empresa

const mostrarPaginaSeleccionada = (pagina) => {
  localStorage.setItem("ultimaOpcionSeleccionadaEm", pagina);

  let srcIframe = document.getElementById("iframeEmpresa");

  if (!srcIframe.src.includes(pagina)) {
    srcIframe.src = "agregarActividad.html";
  }

  srcIframe.src = pagina;
};

window.onload = function () {
  const ultimaOpcion = localStorage.getItem("ultimaOpcionSeleccionadaEm");
  if (ultimaOpcion) {
    document.getElementById("iframeEmpresa").src = ultimaOpcion;
  }
};

// Cerrar Sesión

const cerrarSesion = () => {
  localStorage.removeItem("usuario");
  localStorage.removeItem("ultimaOpcionSeleccionadaEm");
  window.location.href = "/pages/auth/iniciarSesion.html";
};
