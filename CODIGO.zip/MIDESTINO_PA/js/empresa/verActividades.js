// obtener todas las actividades

window.onload = () => {
  obtenerActividadesXEmpresa();
};

const obtenerActividadesXEmpresa = async () => {
  const usuario = JSON.parse(localStorage.getItem("usuario"));

  const url = `http://localhost:9999/api/sitios/${usuario.idUsuario}/empresa`;

  const response = await fetch(url, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
    },
  });

  const result = await response.json();

  let contenidoDeTarjetas = "";

  result.listaSitios.forEach((actividad) => {
    contenidoDeTarjetas += `
    <div class="card">
      <div class="card_contiene_titulo">
        <h5 class="card_titulo">${actividad.nombre}</h5>
        <p class="card_text">${actividad.informacionGeneral}</p>
      </div>
      <ul class="lista_grupo_opciones">
        <li class="lista_item">Precio: ${formatoMoneda(actividad.precio)}</li>
        <li class="lista_item">Horario: ${actividad.horario}</li>
        <li class="lista_item">Correo: ${actividad.email}</li>
        <li class="lista_item">Cantidad disponible: ${actividad.cantidad}</li>
        <li class="lista_item">Telefono: ${actividad.telefono}</li>
      </ul>
      <div class="card_btns">
        <button class="btn_card" onclick="abrirModificarSitio(${
          actividad.idSitio
        })">Modificar</button>
        <button class="btn_card" onclick="eliminarProducto(${
          actividad.idSitio
        })">Eliminar</button>
      </div>
    </div>`;
  });

  const elemento = document.getElementById("contenidoSitios");

  if (elemento) {
    elemento.innerHTML = contenidoDeTarjetas;
  }
};

// Abrir modal para modificar sitio

let idSitio = 0;

const abrirModificarSitio = async (id) => {
  document.getElementById("listaActividades").style.display = "none";
  document.getElementById("modiSitio").style.display = "block";

  try {
    idSitio = id;

    const url = "http://localhost:9999/api/sitio/" + id;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });

    const { sitio } = await response.json();

    document.getElementById("selectTipoSitio").value = sitio.tipoSitio;
    document.getElementById("nombreSitio").value = sitio.nombre;
    document.getElementById("direccionSitio").value = sitio.direccion;
    document.getElementById("horarioSitio").value = sitio.horario;
    document.getElementById("emailSitio").value = sitio.email;
    document.getElementById("telefonoSitio").value = sitio.telefono;
    document.getElementById("precioSitio").value = sitio.precio;
    document.getElementById("cantidadSitio").value = sitio.cantidad;
    document.getElementById("informacionGeneralSitio").value =
      sitio.informacionGeneral;
  } catch (error) {
    console.log(error);
  }
};

// Cerrar modal para modificar sitio

const cerrarModificarSitio = () => {
  document.getElementById("modiSitio").style.display = "none";
  document.getElementById("listaActividades").style.display = "block";
};

// Actualizar sitio

const actualizarProducto = async (e) => {
  e.preventDefault();

  const data = Object.fromEntries(new FormData(e.target));

  // Validar que los campos no estén vacíos
  if (Object.values(data).some((input) => input === "")) {
    alert("Todos los campos son obligatorios");
    return;
  }

  const dataConId = {
    ...data,
    idSitio,
  };

  try {
    const url = `http://localhost:9999/api/sitio/${idSitio}`;

    const response = await fetch(url, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(dataConId),
    });

    const result = await response.json();

    obtenerActividadesXEmpresa();

    cerrarModificarSitio();
  } catch (error) {
    console.log(error);
  }
};

document
  .querySelector("#formModiSitio")
  .addEventListener("submit", actualizarProducto);

// Elimiinar sitio

const eliminarProducto = async (id) => {
  const url = `http://localhost:9999/api/sitio/${id}`;

  const response = await fetch(url, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
    },
  });

  const result = await response.json();

  obtenerActividadesXEmpresa();
};

const formatoMoneda = (precio) => {
  return new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency: "COP",
  }).format(precio);
};
