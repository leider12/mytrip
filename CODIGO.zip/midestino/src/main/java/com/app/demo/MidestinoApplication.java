package com.app.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MidestinoApplication {

    public static void main(String[] args) {
        SpringApplication.run(MidestinoApplication.class, args);
    }

}
